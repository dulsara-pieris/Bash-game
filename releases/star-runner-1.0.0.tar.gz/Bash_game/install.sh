#!/usr/bin/env bash
set -e

APP_NAME="star-runner"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)/src"
INSTALL_BIN="/usr/local/bin"
INSTALL_SHARE="/usr/local/share/$APP_NAME"

echo "Installing $APP_NAME…"

# Make sure we have permission
if [ "$EUID" -ne 0 ]; then
  echo "⚠ Please run as root (e.g., sudo $0)"
  exit 1
fi

# Create directories
mkdir -p "$INSTALL_SHARE"
mkdir -p "$INSTALL_BIN"

# Copy game files
cp -r "$SRC_DIR"/* "$INSTALL_SHARE"

# Create a launcher script
cat << 'EOF' > "$INSTALL_BIN/$APP_NAME"
#!/usr/bin/env bash
"$INSTALL_SHARE/star_runner.sh" "$@"
EOF

chmod +x "$INSTALL_BIN/$APP_NAME"

echo "✔ Installed to $INSTALL_SHARE"
echo "✔ Launcher created at $INSTALL_BIN/$APP_NAME"
echo ""
echo "You can now run the game with:"
echo "  $APP_NAME"
